from messageq import messageq

messageq = messageq
